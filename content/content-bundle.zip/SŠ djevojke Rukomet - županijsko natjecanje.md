---
bodovi: 
školska godina: 
oš /sš: 
sport: 
kategorija: 
razina natjecanja: 
skupina: 
sudionici: 
mentori: 
voditelji: 
datum: 
vrijeme: 
sastanak voditelja: 
mjesto: 
voditelj natjecanja: 
sustav natjecanja: 
voditelj natjecanja iznos: 
obvezna dokumentacija: 
prijevoz: 
mjesto polaska: 
vrijeme polaska: 
broj osoba: 
relacija: 
prijevoznik: 
prijevoz iznos: 
medicinari-u-šs: true
medicinari broj voditelja: 
medicinari broj učenika: 
medicinari broj sati: 
preuzimanje rekvizita: 
naziv: 
količina: 
jedinična cijena: 
suci: 
suci sudačka taksa: 
suci putni trošak: 
suci ukupan trošak: 
prvoplasirana ekipa: 
voditelj prvoplasirane ekipe: 
broj ekipa: 
broj natjecatelja: 
broj turnira/utakmica: 
natjecateljsko povjerenstvo: 
bilješke:
---



