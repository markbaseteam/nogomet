### Skupina A

Sudionici:

1. OŠ “Ivan Meštrović” - Vrpolje - ŠSD Mladost
2. OŠ “Viktor Car Emin” - Donji Andrijevci - ŠSD Tomislav
3. OŠ Sibinjskih žrtava - Sibinj - ŠSD Sibinjski sokol

Datum: 07.12.2023.

Mjesto: OŠ “Viktor Car Emin” - Donji Andrijevci

Vrijeme: 09:30

Voditelj natjecanja: Josip Bogdanović, prof.

Obvezna dokumentacija:

- liječnički pregled
- obrazac A i/ili e-iskaznice

Prijevoz: organiziran

Mjesto polaska: OŠ Sibinjskih žrtava - Sibinj

Vrijeme polaska: 08:00

Broj osoba: 30

Relacija:

1. OŠ Sibinjskih žrtava - Sibinj
2. OŠ “Ivan Meštrović” - Vrpolje
3. OŠ “Viktor Car Emin” - Donji Andrijevci

### Skupina B

Sudionici:

1. OŠ “Matija Antun Relković” - Davor - ŠSD Matija Antun Relković
2. OŠ “Matija Gubec” - Cernik - ŠSD Lipa
3. OŠ “Mato Lovrak” - Nova Gradiška - ŠSD Bedem

Datum: 07.12.2023.

Mjesto: OŠ “Matija Antun Relković” - Davor

Vrijeme: 09:30

Voditelj natjecanja: Matej Paunov, prof.

Obvezna dokumentacija:

- liječnički pregled
- obrazac A i/ili e-iskaznice

Prijevoz: organiziran

Mjesto polaska: OŠ “Matija Gubec” - Cernik

Vrijeme polaska: 08:30

Broj osoba: 30

Relacija:

1. OŠ Sibinjskih žrtava - Sibinj
2. OŠ “Ivan Meštrović” - Vrpolje
3. OŠ “Viktor Car Emin” - Donji Andrijevci

### Skupina C

Sudionici:

1. OŠ “Hugo Badalić” - Slavonski Brod - ŠSD Plavi sokol
2. OŠ “Bogoslav Šulek” - Slavonski Brod - ŠSD Sporting
3. OŠ “Blaž Tadijanović” - Slavonski Brod - ŠSD Podvinje

Datum: 08.12.2023.

Mjesto: SD "Vijuš", Slavonski Brod

Vrijeme: 12:00

Voditelj natjecanja: Dražen Gusak, prof.

Obvezna dokumentacija:

- liječnički pregled
- obrazac A i/ili e-iskaznice

Prijevoz: organiziran

Mjesto polaska: OŠ “Blaž Tadijanović” - Slavonski Brod

Vrijeme polaska: 11:30

Broj osoba: 30

Relacija:

1. OŠ “Blaž Tadijanović” - Slavonski Brod
2. OŠ “Bogoslav Šulek” - Slavonski Brod
3. OŠ “Hugo Badalić” - Slavonski Brod
4. SD "Vijuš", Slavonski Brod