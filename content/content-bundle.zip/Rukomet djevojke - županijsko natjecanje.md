## Županijsko natjecanje

Sudionici:

1. Klasična gimnazija - Slavonski Brod - ŠSD Klasičar
2. Srednja medicinska škola - Slavonski Brod - ŠSD SMŠ

Datum: 16.11.2023.

Vrijeme: 12:00

Sastanak voditelja: 11:45

Mjesto: SD "Vijuš, Slavonski Brod

Voditelj natjecanja: Bruno Štefanek

Obvezna dokumentacija:

- liječnički pregled
- obrazac A i/ili e-iskaznice